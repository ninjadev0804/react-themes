export const jobData = [
  {
    id: 1,
    title: "UI / UX Designer",
    experience: "3 to 5 years",
    desc: ` We are looking for a full-time Software QA Analyst to be part of
              our team to ensure the top-notch quality, overall functionality
              and usability.`,
  },
  {
    id: 2,
    title: "Full Stack Engineer",
    experience: "3 to 5 years",
    desc: ` We are looking for a full-time Software QA Analyst to be part of
              our team to ensure the top-notch quality, overall functionality
              and usability.`,
  },
  {
    id: 3,
    title: "Content Writer",
    experience: "1 to 2 years",
    desc: ` We are looking for a full-time Software QA Analyst to be part of
              our team to ensure the top-notch quality, overall functionality
              and usability.`,
  },
  {
    id: 4,
    title: "React Developer",
    experience: "3 to 5 years",
    desc: ` We are looking for a full-time Software QA Analyst to be part of
              our team to ensure the top-notch quality, overall functionality
              and usability.`,
  },
  {
    id: 5,
    title: "Growth Hacker",
    experience: "3 to 5 years",
    desc: ` We are looking for a full-time Software QA Analyst to be part of
              our team to ensure the top-notch quality, overall functionality
              and usability.`,
  },
  {
    id: 6,
    title: "Media Marketer",
    experience: "3 to 5 years",
    desc: ` We are looking for a full-time Software QA Analyst to be part of
              our team to ensure the top-notch quality, overall functionality
              and usability.`,
  },
];
export const benefitsData = [
  { id: 1, text: "Paid family leave" },
  { id: 2, text: "Flexible hours" },
  { id: 3, text: "Unlimited Coffee" },
  { id: 4, text: "Health insurance" },
  { id: 5, text: "Challenging Work" },
  { id: 6, text: "Great Pay" },
];
