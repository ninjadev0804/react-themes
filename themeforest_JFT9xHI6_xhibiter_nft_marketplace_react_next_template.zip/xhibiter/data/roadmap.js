export const roadmap = [
  {
    id: 1,
    quarter: "2021 Q3",
    desc: `    Interested investors can buy into an initial coin offering to
                receive a new cryptocurrency token issued by the company. This
                token may have some utility related to the product or service
                that the company is offering or represent a stake in the company
                or project.`,
  },
  {
    id: 2,
    quarter: "2021 Q4",
    desc: `     This timeline details our funding and development goals. Connect
                our AI to your exchange account and invest crypto automatically.`,
  },
  {
    id: 3,
    quarter: "2022 Q1",
    desc: `   It is commonly adopted, applies to secure message transmission
                either directly without any key distribution in advance. This
                token may have some utility related to the product or service
                that the company is offering or represent a stake in the company
                or project.`,
  },
  {
    id: 4,
    quarter: "2022 Q2",
    desc: `    Interested investors can buy into an initial coin offering to
                receive a new cryptocurrency token issued by the company. This
                token may have some utility related to the product or service
                that the company is offering or represent a stake in the company
                or project.`,
  },
  {
    id: 5,
    quarter: "2022 Q3",
    desc: `     It is commonly adopted, applies to secure message transmission
                either directly without any key distribution in advance. This
                token may have some utility related to the product or service
                that the company is offering or represent a stake in the company
                or project.`,
  },
  {
    id: 6,
    quarter: "2022 Q4",
    desc: `    This timeline details our funding and development goals. Connect
                our AI to your exchange account and invest crypto automatically.`,
  },
  {
    id: 7,
    quarter: "2023 Q1",
    desc: `      It is commonly adopted, applies to secure message transmission
                either directly without any key distribution in advance. This
                token may have some utility related to the product or service
                that the company is offering or represent a stake in the company
                or project.`,
  },
];
