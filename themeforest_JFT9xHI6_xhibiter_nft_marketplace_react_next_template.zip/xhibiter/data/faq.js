export const faqs = [
  {
    id: 1,
    question: "What is tax and legal advisory?",
    answer: ` Learn how to create your very first NFT and how to create
                      your NFT collections. Unique, fully 3D and built to unite
                      the design multiverse. Designed and styled by Digimental.`,
  },
  {
    id: 2,
    question: "How can I stay safe and protect my NFTs ?",
    answer: ` Learn how to create your very first NFT and how to create
                      your NFT collections. Unique, fully 3D and built to unite
                      the design multiverse. Designed and styled by Digimental.`,
  },
  {
    id: 3,
    question: "Do you give guarantee and after sales service?",
    answer: ` Learn how to create your very first NFT and how to create
                      your NFT collections. Unique, fully 3D and built to unite
                      the design multiverse. Designed and styled by Digimental.`,
  },
];
export const faqs2 = [
  {
    id: 1,
    question: "How do I create an NFT?",
    answer: ` Learn how to create your very first NFT and how to create
                      your NFT collections. Unique, fully 3D and built to unite
                      the design multiverse. Designed and styled by Digimental.`,
  },
  {
    id: 2,
    question: "How can I stay safe and protect my NFTs ?",
    answer: ` Learn how to create your very first NFT and how to create
                      your NFT collections. Unique, fully 3D and built to unite
                      the design multiverse. Designed and styled by Digimental.`,
  },
  {
    id: 3,
    question: "What are the key terms to know in NFTs and Web3 ?",
    answer: ` Learn how to create your very first NFT and how to create
                      your NFT collections. Unique, fully 3D and built to unite
                      the design multiverse. Designed and styled by Digimental.`,
  },
  {
    id: 4,
    question: "How do I sell an NFT ?",
    answer: ` Learn how to create your very first NFT and how to create
                      your NFT collections. Unique, fully 3D and built to unite
                      the design multiverse. Designed and styled by Digimental.`,
  },
  {
    id: 5,
    question: "Smart Contract Upgrade: What You Need to Know",
    answer: ` Learn how to create your very first NFT and how to create
                      your NFT collections. Unique, fully 3D and built to unite
                      the design multiverse. Designed and styled by Digimental.`,
  },
];
export const faqs3 = [
  {
    id: 1,
    question: "How an Initial Coin Offering (ICO) Works",
    answer: ` Learn how to create your very first NFT and how to create
                      your NFT collections. Unique, fully 3D and built to unite
                      the design multiverse. Designed and styled by Digimental.`,
  },
  {
    id: 2,
    question: "White Paper Release",
    answer: ` Learn how to create your very first NFT and how to create
                      your NFT collections. Unique, fully 3D and built to unite
                      the design multiverse. Designed and styled by Digimental.`,
  },
  {
    id: 3,
    question: "What Happens to the Funds?",
    answer: ` Learn how to create your very first NFT and how to create
                      your NFT collections. Unique, fully 3D and built to unite
                      the design multiverse. Designed and styled by Digimental.`,
  },
  {
    id: 4,
    question: "Who Can Launch an ICO?",
    answer: ` Learn how to create your very first NFT and how to create
                      your NFT collections. Unique, fully 3D and built to unite
                      the design multiverse. Designed and styled by Digimental.`,
  },
  {
    id: 5,
    question: "Buying Into an ICO",
    answer: ` Learn how to create your very first NFT and how to create
                      your NFT collections. Unique, fully 3D and built to unite
                      the design multiverse. Designed and styled by Digimental.`,
  },
];
