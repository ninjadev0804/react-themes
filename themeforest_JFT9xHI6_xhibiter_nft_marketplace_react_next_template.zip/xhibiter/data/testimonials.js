export const testimonialsData = [
  {
    id: 1,
    imageSrc: "/img/testimonials/testimonial_1.jpg",
    text: "Xhibiter is one of the most exciting, if you're interested in shaping a new business model for creators, this is the team to join.",
    name: "Katie Smith",
    role: "General Partner at Entrepreneur",
  },
  {
    id: 2,
    imageSrc: "/img/testimonials/testimonial_2.jpg",
    text: "Xhibiter is one of the most exciting, if you're interested in shaping a new business model for creators, this is the team to join.",
    name: "Alex Fox",
    role: "Entrepreneur / Manager",
  },
  {
    id: 3,
    imageSrc: "/img/testimonials/testimonial_3.jpg",
    text: "Xhibiter is one of the most exciting, if you're interested in shaping a new business model for creators, this is the team to join.",
    name: "Marshal Ericson",
    role: "NFT Entrepreneur",
  },
  {
    id: 1,
    imageSrc: "/img/testimonials/testimonial_1.jpg",
    text: "Xhibiter is one of the most exciting, if you're interested in shaping a new business model for creators, this is the team to join.",
    name: "Katie Smith",
    role: "General Partner at Entrepreneur",
  },
  {
    id: 2,
    imageSrc: "/img/testimonials/testimonial_2.jpg",
    text: "Xhibiter is one of the most exciting, if you're interested in shaping a new business model for creators, this is the team to join.",
    name: "Alex Fox",
    role: "Entrepreneur / Manager",
  },
  {
    id: 3,
    imageSrc: "/img/testimonials/testimonial_3.jpg",
    text: "Xhibiter is one of the most exciting, if you're interested in shaping a new business model for creators, this is the team to join.",
    name: "Marshal Ericson",
    role: "NFT Entrepreneur",
  },
];
