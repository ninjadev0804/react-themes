export const blogs = [
  {
    id: 1,
    category: "Finance",
    date: "2022-02-05",
    title: "10 Marketing Trends That You Should Be Prepared for in 2022",
    content:
      "The goal of this new editor is to make adding rich content to WordPress simple…",
  },
  {
    id: 2,
    category: "Finance",
    date: "2022-02-05",
    title: "Expanding the Global NFT Ecosystem: A Preview of Chain Expansion",
    content:
      "The goal of this new editor is to make adding rich content to WordPress simple…",
  },
  {
    id: 3,
    category: "Finance",
    date: "2022-02-05",
    title: "OpenSea Acquires Gem to Invest in Pro Experience",
    content:
      "The goal of this new editor is to make adding rich content to WordPress simple…",
  },
  {
    id: 4,
    category: "Finance",
    date: "2022-02-05",
    title: "10 Marketing Trends That You Should Be Prepared for in 2022",
    content:
      "The goal of this new editor is to make adding rich content to WordPress simple…",
  },
  {
    id: 5,
    category: "Finance",
    date: "2022-02-05",
    title: "Expanding the Global NFT Ecosystem: A Preview of Chain Expansion",
    content:
      "The goal of this new editor is to make adding rich content to WordPress simple…",
  },
  {
    id: 6,
    category: "Finance",
    date: "2022-02-05",
    title: "OpenSea Acquires Gem to Invest in Pro Experience",
    content:
      "The goal of this new editor is to make adding rich content to WordPress simple…",
  },
];
export const blogs2 = [
  {
    id: 5,
    imgSrc: "/img/blog/post_2.jpg",
    alt: "post 2",
    title: "Mint your own Tezos collections",
    date: "5 Feb",
    writer: "Deothemes",
    category: `NFT's
DIGITAL ART`,
    desc: "Since we launched Tezos at the end of 2021, many awesome creators...",
  },
  {
    id: 6,
    imgSrc: "/img/blog/post_3.jpg",
    alt: "post 3",
    title: "List your collection for secondary sales",
    date: "22 Feb",
    writer: "Deothemes",
    category: `NFT's
DIGITAL ART`,
    desc: "Since we launched Tezos at the end of 2021, many awesome creators...",
  },
  {
    id: 7,
    imgSrc: "/img/blog/post_4.jpg",
    alt: "post 4",
    title: "The biggest moves in NFTs, Bitcoin, crypto rules",
    date: "18 Jan",
    writer: "Deothemes",
    category: `NFT's
DIGITAL ART`,
    desc: "Since we launched Tezos at the end of 2021, many awesome creators...",
  },
  {
    id: 8,
    imgSrc: "/img/blog/post_5.jpg",
    alt: "post 4",
    title: "Incredible Amount of Developer Energy' in Web3",
    date: "8 Jan",
    writer: "Deothemes",
    category: `NFT's
DIGITAL ART`,
    desc: "Since we launched Tezos at the end of 2021, many awesome creators...",
  },
  {
    id: 9,
    imgSrc: "/img/blog/post_6.jpg",
    alt: "post 4",
    title: "Inflation is up, it matters: High prices plague Biden's",
    date: "1 Jan",
    writer: "Deothemes",
    category: `NFT's
DIGITAL ART`,
    desc: "Since we launched Tezos at the end of 2021, many awesome creators...",
  },
  {
    id: 10,
    imgSrc: "/img/blog/post_7.jpg",
    alt: "post 4",
    title: "What to do when the market is going everywhere",
    date: "17 Jan",
    writer: "Deothemes",
    category: `NFT's
DIGITAL ART`,
    desc: "Since we launched Tezos at the end of 2021, many awesome creators...",
  },
];
export const blogs3 = [
  {
    id: 11,
    imgSrc: "/img/blog/post_1.jpg",
    alt: "post 2",
    title: "List your collection for secondary sales",
    date: "5 Feb",
    writer: "Deothemes",
    category: `NFT's
DIGITAL ART`,
    desc: "Since we launched Tezos at the end of 2021, many awesome creators...",
  },
];

export const allBlogs = [...blogs, ...blogs2, , , blogs3];
