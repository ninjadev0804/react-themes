export const items = [
  {
    id: 1,
    href: "#",
    title: "Getting started",
    description:
      "Learn how to create an account, set up your wallet, and what you can do.",
  },
  {
    id: 2,
    href: "#",
    title: "Buying",
    description:
      "Learn how to create an account, set up your wallet, and what you can do.",
  },
  {
    id: 3,
    href: "#",
    title: "Selling",
    description:
      "Learn how to create an account, set up your wallet, and what you can do.",
  },
  {
    id: 4,
    href: "#",
    title: "Creating",
    description:
      "Learn how to create an account, set up your wallet, and what you can do.",
  },
  {
    id: 5,
    href: "#",
    title: "User Safety",
    description:
      "Learn how to create an account, set up your wallet, and what you can do.",
  },
  {
    id: 6,
    href: "#",
    title: "Partners",
    description:
      "Learn how to create an account, set up your wallet, and what you can do.",
  },
];
