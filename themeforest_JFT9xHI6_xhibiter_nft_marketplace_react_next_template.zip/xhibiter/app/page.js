import HomePage1 from "./(homes)/home-1/page";

export const metadata = {
  title: "Home 1 || Xhibiter | NFT Marketplace Nextjs Template",
};

export default function Home() {
  return (
    <>
      <HomePage1 />
    </>
  );
}
