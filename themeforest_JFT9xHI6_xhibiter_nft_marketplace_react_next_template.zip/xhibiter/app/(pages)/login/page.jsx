import Login from "@/components/pages/Login";

export const metadata = {
  title: "Login || Xhibiter | NFT Marketplace Nextjs Template",
};

export default function LoginPage() {
  return (
    <>
      <Login />
    </>
  );
}
